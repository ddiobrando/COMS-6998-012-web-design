from flask import Flask, render_template, request, jsonify
import openai
import requests  # To make HTTP requests to the photo-gen API

app = Flask(__name__)
openai.api_key = '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'

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/remix', methods=['POST'])
def remix_recipe():
    recipe = request.form['recipe']

    # Call to OpenAI for alternative recipe suggestions
    response1 = openai.ChatCompletion.create(
        model="gpt-3.5-turbo",  # replace with chatgpt if you have a specific model name
        messages=[{"role": "system", "content": f"{recipe}: Please provide a detailed recipe."}],
    )
    alternative_recipe = response1.get("choices")[0]["message"]["content"]


    # Call to OpenAI for ingredient substitutions
    response2 = openai.ChatCompletion.create(
        model="gpt-3.5-turbo",  # replace with chatgpt if you have a specific model name
        messages=[{"role": "system", "content": f"Give a title of this dish: {alternative_recipe}"}],
    )
    recipe_name = response2.get("choices")[0]["message"]["content"]

    # Call to the photo-generation AI
    photo_response = openai.Image.create(
        prompt= recipe_name,
        n=1,
        size="1024x1024"
    )
    image_url = photo_response['data'][0]['url']

    return jsonify({
        'alternative_recipe': alternative_recipe,
        'recipe_name': recipe_name,
        'photo_url': image_url
    })

if __name__ == '__main__':
    app.run(debug=True)